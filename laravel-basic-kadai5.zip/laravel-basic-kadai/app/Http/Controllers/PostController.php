<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\posts;


class PostController extends Controller{
    //
    Public function index(){
        $posts = DB::table('posts')->get();
        return view('posts.index', compact('posts'));
    }

    Public function show($id){
        $post = posts::find($id);

        return view('posts.show', compact('post'));
    
    }

    public function create(){
        return view('posts.create');

   }

    public function store(Request $request){
        $request->validate([
            //バリデーションの追加
            "title"=> 'required|max:20',
            "content"=> 'required|max:200'
        ]);

        //フォームへの追加
        $post = new Posts(); 
        $post->title = $request->input('title');
        $post->content = $request->input('content');
        $post->save();

        return redirect("/posts");
    }
}
